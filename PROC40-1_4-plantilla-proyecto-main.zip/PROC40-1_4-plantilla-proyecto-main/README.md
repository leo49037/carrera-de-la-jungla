# PROC40-1_4-plantilla-proyecto
## Plantilla del proyecto para la clase 40 nivel PRO 1:4.
Modificación por parte del alumno de un comentarios y cambio en la configuración de Firebase de la base de datos. 

### Nombre en Inglés: Jungle-Racer-Template